﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY Daniel Vaughan ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL Daniel Vaughan BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2010-04-10 20:33:35Z</CreationDate>
	<Origin>http://www.calciumsdk.com</Origin>
</File>
*/
#endregion

using System;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Runtime.Serialization;

namespace DanielVaughan.ComponentModel
{
	/// <summary>
	/// A base class for property change notification.
	/// <seealso cref="PropertyChangeNotifier"/>.
	/// </summary>
	public abstract class NotifyPropertyChangeBase : INotifyPropertyChanged, INotifyPropertyChanging
	{
		PropertyChangeNotifier notifier;

		object notifierLock;

		/// <summary>
		/// Gets the notifier. It is lazy loaded.
		/// </summary>
		/// <value>The notifier.</value>
		protected PropertyChangeNotifier Notifier
		{
			get
			{
				/* It is cheaper to create an object to lock, than to instantiate 
				 * the PropertyChangeNotifier, because hooking up the events 
				 * for many instances is expensive. */
				if (notifier == null)
				{
					lock (notifierLock)
					{
						if (notifier == null)
						{
							notifier = new PropertyChangeNotifier(this);
						}
					}
				}
				return notifier;
			}
		}

		protected void OnPropertyChanged(string propertyName)
		{
			Notifier.NotifyChanged(propertyName);
		}

		protected void OnPropertyChanged<TProperty>(
			Expression<Func<TProperty>> expression)
		{
			Notifier.NotifyChanged(expression);
		}

		protected void OnPropertyChanging<TProperty>(
			string propertyName, TProperty oldValue, TProperty newValue)
		{
			Notifier.NotifyChanging(propertyName, oldValue, newValue);
		}

		protected void OnPropertyChanging<TProperty>(
			Expression<Func<TProperty>> expression, TProperty oldValue, TProperty newValue)
		{
			Notifier.NotifyChanging(expression, oldValue, newValue);
		}

		//[OnDeserializing]
		void OnDeserializing(StreamingContext context)
		{
			Initialize();
		}

		/// <summary>
		/// Assigns the specified newValue to the specified property
		/// and then notifies listeners that the property has changed.
		/// </summary>
		/// <typeparam name="TProperty">The type of the property.</typeparam>
		/// <param name="propertyName">Name of the property. Can not be null.</param>
		/// <param name="property">A reference to the property that is to be assigned.</param>
		/// <param name="newValue">The value to assign the property.</param>
		/// <exception cref="ArgumentNullException">
		/// Occurs if the specified propertyName is <code>null</code>.</exception>
		/// <exception cref="ArgumentException">
		/// Occurs if the specified propertyName is an empty string.</exception>
		protected AssignmentResult Assign<TProperty>(
			string propertyName, ref TProperty property, TProperty newValue)
		{
			return Notifier.Assign(propertyName, ref property, newValue);
		}

		/// <summary>
		/// Slow. Not recommended.
		/// Assigns the specified newValue to the specified property
		/// and then notifies listeners that the property has changed.
		/// Assignment nor notification will occur if the specified
		/// property and newValue are equal. 
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <typeparam name="TProperty">The type of the property.</typeparam>
		/// <param name="expression">The expression that is used to derive the property name.
		/// Should not be <code>null</code>.</param>
		/// <param name="property">A reference to the property that is to be assigned.</param>
		/// <param name="newValue">The value to assign the property.</param>
		/// <exception cref="ArgumentNullException">
		/// Occurs if the specified propertyName is <code>null</code>.</exception>
		/// <exception cref="ArgumentException">
		/// Occurs if the specified propertyName is an empty string.</exception>
		public AssignmentResult Assign<TProperty>(
			Expression<Func<TProperty>> expression, ref TProperty property, TProperty newValue)
		{
			return Notifier.Assign(expression, ref property, newValue);
		}

		/// <summary>
		/// When deserialization occurs fields are not instantiated,
		/// therefore we must instantiate the notifier.
		/// </summary>
		void Initialize()
		{
			notifierLock = new object();
		}

		public NotifyPropertyChangeBase()
		{
			Initialize();
		}

		#region Property change notification

		/// <summary>
		/// Occurs when a property value changes.
		/// <seealso cref="PropertyChangeNotifier"/>
		/// </summary>
		public event PropertyChangedEventHandler PropertyChanged
		{
			add
			{
				Notifier.PropertyChanged += value;
			}
			remove
			{
				Notifier.PropertyChanged -= value;
			}
		}

		/// <summary>
		/// Occurs when a property value is changing.
		/// <seealso cref="PropertyChangeNotifier"/>
		/// </summary>
		public event PropertyChangingEventHandler PropertyChanging
		{
			add
			{
				Notifier.PropertyChanging += value;
			}
			remove
			{
				Notifier.PropertyChanging -= value;
			}
		}

		#endregion
	}
}
