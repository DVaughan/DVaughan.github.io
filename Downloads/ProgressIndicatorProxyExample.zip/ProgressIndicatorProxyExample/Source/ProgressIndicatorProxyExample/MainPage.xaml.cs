﻿using Microsoft.Phone.Controls;

namespace DanielVaughan.Windows
{
	public partial class MainPage : PhoneApplicationPage
	{
		public MainPage()
		{
			InitializeComponent();
			DataContext = new MainPageViewModel();
		}
	}
}