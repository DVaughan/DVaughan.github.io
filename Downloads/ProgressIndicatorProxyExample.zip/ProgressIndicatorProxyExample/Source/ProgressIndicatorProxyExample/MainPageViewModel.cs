﻿namespace DanielVaughan.Windows
{
	public class MainPageViewModel : ViewModelBase
	{
		bool indeterminate;

		public bool Indeterminate
		{
			get
			{
				return indeterminate;
			}
			set
			{
				Assign(() => Indeterminate, ref indeterminate, value);
			}
		}

		double progress = .5;

		public double Progress
		{
			get
			{
				return progress;
			}
			set
			{
				Assign(() => Progress, ref progress, value);
			}
		}

		string message = "Loading message";

		public string Message
		{
			get
			{
				return message;
			}
			set
			{
				Assign(() => Message, ref message, value);
			}
		}
	}
}
