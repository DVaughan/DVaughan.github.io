﻿using Microsoft.Phone.Controls;

namespace DanielVaughan.ManifestGeneration
{
	public partial class MainPage : PhoneApplicationPage
	{

		public MainPage()
		{
			InitializeComponent();

			ApplicationTitle.Text = DeploymentConfiguration.Paid ? "MY APP PRO" : "MY APP FREE";
		}
	}
}