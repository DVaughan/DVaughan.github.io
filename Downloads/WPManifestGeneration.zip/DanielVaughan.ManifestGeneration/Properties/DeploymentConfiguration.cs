﻿#define PAID

class DeploymentConfiguration
{
	/// <summary>
	/// The app identifier for the non-free version of the app. 
	/// This is used to provide a link to buy the paid app from the free app.
	/// </summary>
	public static string PaidAppId
	{
		get
		{
			return "11111111-1111-1111-1111-11111111";
		}
	}

	public static string AdAppId
	{
		get
		{
#if DEBUG
			return "test_client";
#else
			return "11111111-1111-1111-1111-11111111";
#endif
		}
	}

	public static string AdUnitId
	{
		get
		{
			return "11111";
		}
	}

	/* This should be false when publishing a paid version; true otherwise. */
	public static bool ShowAds
	{
		get
		{
			return !PaidConfiguration;
		}
	}

	public static bool Paid
	{
		get
		{
			return PaidConfiguration;
		}
	}

	public const bool PaidConfiguration =
#if PAID
 true;
#else
 false;
#endif
}