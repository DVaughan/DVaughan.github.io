﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WebserviceCallOnShutdown
{
	public partial class MainPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

		public void SetNotice(string text)
		{
			textBlock_State.Text = text;
		}

		public bool Dirty
		{
			get
			{
				return CheckBox_ShowDialog.IsChecked == true;
			}
			set
			{
				CheckBox_ShowDialog.IsChecked = false;
			}
		}

		void CheckBox_ShowDialog_Checked(object sender, RoutedEventArgs e)
		{
			SetNotice("This page will now give the Silverlight application opportunity \n to call a webservice and prompt the user before closing.");
		}
	}
}
