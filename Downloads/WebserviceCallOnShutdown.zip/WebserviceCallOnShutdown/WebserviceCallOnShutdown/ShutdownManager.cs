﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using WebserviceCallOnShutdown.ShutdownServiceReference;

namespace WebserviceCallOnShutdown
{
	[ScriptableType]
	public class ShutdownManager
	{
		[ScriptableMember]
		public string Shutdown()
		{
			string result = null;
			var page = (MainPage)Application.Current.RootVisual;

			if (page.Dirty)
			{
				var messageBoxResult = MessageBox.Show(
					"Save changes you have made?", "Save changes?", MessageBoxButton.OKCancel);
				if (messageBoxResult == MessageBoxResult.OK)
				{
					var waitingWindow = new WaitingWindow();
					waitingWindow.Show();

					waitingWindow.NoticeText = "Saving work on server. Please wait...";
					page.SetNotice("Saving work on server. Please wait...");

					var client = new ShutdownServiceClient();
					client.SaveWorkCompleted += ((sender, e) =>
						{
							waitingWindow.NoticeText = "It is now safe to close this window.";
							page.SetNotice("It is now safe to close this window.");
							page.Dirty = false;
							waitingWindow.Close();
						});
					client.SaveWorkAsync("Test id");
					result = "Saving changes.";
				}
				else
				{
					result = "If you close this window you will lose any unsaved work.";
				}
			}

            return result;
		}
	}
}
