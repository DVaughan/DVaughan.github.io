﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-11-03 23:12:56Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.Reflection;

namespace DanielVaughan.Communication
{
	/// <summary>
	/// Use <code>IChannelManager</code> to create simplex and duplex WCF channels.
	/// </summary>
	public interface IChannelManager
	{
		/// <summary>
		/// Creates or retrieves a cached service channel.
		/// <example>
		///	var simpleService = ChannelManagerSingleton.Instance.GetChannel<ISimpleService>();
		///	string result = string.Empty;
		///	try
		///	{
		///		/* Perform synchronous WCF call. */
		///		result = SynchronousChannelBroker.PerformAction<string, string>(
		///			simpleService.BeginGetGreeting, simpleService.EndGetGreeting, "there");
		///	}
		///	catch (TargetInvocationException ex)
		///	{
		///		DisplayMessage(string.Format("Unable to communicate with server. {0} {1}", 
		///			ex.Message, ex.StackTrace));
		///	}
		/// </example>
		/// </summary>
		/// <returns>A channel of the specified type.</returns>
		/// <exception cref="TargetInvocationException">Occurs if the service implements <code>IClientService</code>, 
		/// and the call to ConnectFromClient results in a <code>TargetInvocationException</code></exception>
		TService GetChannel<TService>();

		/// <summary>
		/// Creates a duplex service channel.
		/// <example>
		///	var simpleDuplexService = ChannelManagerSingleton.Instance.GetDuplexChannel<IMyService>(new MyServiceCallback());
		///	string result = string.Empty;
		///	try
		///	{
		///		/* Perform synchronous WCF call. */
		///		result = SynchronousChannelBroker.PerformAction<string, string>(
		///			simpleDuplexService.BeginGetGreeting, simpleDuplexService.EndGetGreeting, "there");
		///	}
		///	catch (TargetInvocationException ex)
		///	{
		///		DisplayMessage(string.Format("Unable to communicate with server. {0} {1}", 
		///			ex.Message, ex.StackTrace));
		///	}
		/// </example>
		/// <example>
		/// var channelManager = unityContainer.Resolve&lt;IChannelManager&gt;();
		/// var myService = channelManager.GetDuplexChannel<IMyService>(new MyServiceCallback());
		/// </example>
		/// </summary>
		/// <param name="callbackInstance">Is used by the server to communicate to the client.</param>
		/// <returns>A channel of the specified type.</returns>
		/// <exception cref="TargetInvocationException">Occurs if the service implements <code>IClientService</code>, 
		/// and the call to ConnectFromClient results in a <code>TargetInvocationException</code></exception>
		TService GetDuplexChannel<TService>(object callbackInstance);
	}
}
