﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-11-03 23:32:33Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Threading;

using DanielVaughan.Concurrency;

namespace DanielVaughan
{
	/// <summary>
	/// Singleton class providing the default implementation 
	/// for the <see cref="ISynchronizationContext"/>, specifically for the UI thread.
	/// </summary>
	public class UISynchronizationContext : ISynchronizationContext
	{
		DispatcherSynchronizationContext context;
		Dispatcher dispatcher;
		
		#region Singleton implementation

		static readonly UISynchronizationContext instance = new UISynchronizationContext();
		
		/// <summary>
		/// Gets the singleton instance.
		/// </summary>
		/// <value>The current.</value>
		public static ISynchronizationContext Instance
		{
			get
			{
				return instance;
			}
		}

		UISynchronizationContext()
		{
			try
			{
				dispatcher = HtmlPage.Document.Dispatcher;
				context = new DispatcherSynchronizationContext(dispatcher);
			}
			catch (Exception)
			{
				/* This occurs if called from a non-ui thread. Ignore. */
				//Debug.WriteLine("Unable to get root visual in private constructor of UISynchronizationContext." + ex);/* TODO: Make localizable resource. */
			}

		}

		#endregion

		public void Initialize()
		{
			EnsureInitialized();
		}

		[MethodImpl(MethodImplOptions.Synchronized)]
		void EnsureInitialized()
		{
			if (dispatcher != null && context != null)
			{
				return;
			}

			try
			{
				dispatcher = HtmlPage.Document.Dispatcher;
				context = new DispatcherSynchronizationContext(dispatcher);
			}
			catch (InvalidOperationException)
			{
				throw new ConcurrencyException("Initialised called from non-UI thread."); /* TODO: Make localizable resource. */
			}
		}

		public void Initialize(Dispatcher dispatcher)
		{
			ArgumentValidator.AssertNotNull(dispatcher, "dispatcher");
			this.dispatcher = dispatcher;
			context = new DispatcherSynchronizationContext(dispatcher);
		}

		public void InvokeAsynchronously(SendOrPostCallback callback, object state)
		{
			ArgumentValidator.AssertNotNull(callback, "callback");
			EnsureInitialized();

			context.Post(callback, state);
		}

		public void InvokeAsynchronously(Action action)
		{
			ArgumentValidator.AssertNotNull(action, "action");
			EnsureInitialized();

			if (dispatcher.CheckAccess())
			{
				action();
			}
			else
			{
				dispatcher.BeginInvoke(action);
			}
		}

		public void InvokeSynchronously(SendOrPostCallback callback, object state)
		{
			ArgumentValidator.AssertNotNull(callback, "callback");
			EnsureInitialized();

			context.Send(callback, state);
		}

		public void InvokeSynchronously(Action action)
		{
			ArgumentValidator.AssertNotNull(action, "action");
			EnsureInitialized();

			if (dispatcher.CheckAccess())
			{
				action();
			}
			else
			{
				context.Send(delegate { action(); }, null);
			}
		}

		public bool InvokeRequired
		{
			get
			{
				EnsureInitialized();
				return !dispatcher.CheckAccess();
			}
		}
	}
}
