﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-11-03 23:34:49Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.ComponentModel;

namespace DanielVaughan
{
	/// <summary>
	/// The exception that may be thrown by the core library.
	/// </summary>
	public class CoreException : Exception
	{
		public CoreException()
		{
		}

		public CoreException(string message) : base(message)
		{
		}

		public CoreException(string message, Exception ex)
			: base(message, ex)
		{
		}

	}
}
