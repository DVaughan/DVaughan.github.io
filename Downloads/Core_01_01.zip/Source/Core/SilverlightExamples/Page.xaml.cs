﻿using System;
using System.ServiceModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;

using DanielVaughan.Silverlight.Examples.SimpleServiceReference;

namespace DanielVaughan.Silverlight.Examples
{
	public partial class Page
	{
		public Page()
		{
			InitializeComponent();
			UISynchronizationContext.Instance.Initialize(Dispatcher);
		}

		void Button_CallSynchronously_Click(object sender, RoutedEventArgs e)
		{
			GetGreetingFromServer();
		}

		void GetGreetingFromServer()
		{
			DisplayGreeting(string.Empty);

			#region Call service synchronously on a thread pool thread using the ChannelManager.
			ThreadPool.QueueUserWorkItem(delegate
			{
				DisplayMessage("Calling server synchronously.");
				CallWcfSynchronouslyUsingChannelManager();
				DisplayMessage("Finished synchronous call.");
			});
			#endregion

			#region Call service synchronously on a thread pool thread using a proxy and an AutoResetEvent.
			ThreadPool.QueueUserWorkItem(delegate
			{
				DisplayMessage("Calling server synchronously.");
				
				var resetEvent = new ManualResetEvent(false);
				var client = new SimpleServiceClient();
				client.GetGreetingCompleted += ((sender, e) =>
				{
					var threadId = Thread.CurrentThread.ManagedThreadId.ToString();
					DisplayMessage("Callback thread id: " + threadId);
					DisplayGreeting(e.Result + threadId);
					resetEvent.Set();
				});
				client.GetGreetingAsync("SimpleServiceClient");
				resetEvent.WaitOne();
				DisplayMessage("Finished synchronous call.");
			});
			#endregion
            
			#region Calling a service synchronously from the UI thread will block indefinately. Uncomment to test.
			//CallWcfSynchronously();
			#endregion

			#region But if we use a non-UI thread everything is ok. Uncomment to test.
			//ThreadPool.QueueUserWorkItem(delegate { CallWcfSynchronously(); });
			#endregion

			#region Call service asynchronously using ordinary approach. Uncomment to test.
			//            ThreadPool.QueueUserWorkItem(delegate
			//			                             	{
			//												string threadId = Thread.CurrentThread.ManagedThreadId.ToString();
			//			                             		DisplayMessage("Main thread id: " + threadId);
			//			                             		var client = new SimpleServiceClient();
			//			                             		client.GetGreetingAsync("SimpleServiceClient");
			//			                             		Thread.Sleep(1000);
			//			                             		/* Sleep for a moment to demonstrate that the call doesn't occur until later. */
			//			                             		/* Subscribing to the event on the UI thread, after the service call, still works! */
			//			                             		client.GetGreetingCompleted += ((sender, e) =>
			//			                             		                                	{
			//			                             		                                		threadId = Thread.CurrentThread.ManagedThreadId.ToString();
			//			                             		                                		DisplayMessage("Callback thread id: " + threadId);
			//			                             		                                		DisplayGreeting(e.Result + threadId);
			//			                             		                                	});
			//			                             	});
			#endregion

			#region Call service asynchronously but waiting for completion will block indefinately. Uncomment to test.
			//			var resetEvent = new ManualResetEvent(false);
			//			var client = new SimpleServiceClient();
			//			client.GetGreetingCompleted += ((sender, e) =>
			//			                                	{
			//			                                		DisplayGreeting(e.Result);
			//			                                		resetEvent.Set();
			//			                                	});
			//			client.GetGreetingAsync("SimpleServiceClient");
			//			resetEvent.WaitOne(); /* This will block indefinately. */
			#endregion
		}

		void CallWcfSynchronouslyUsingChannelManager()
		{
			var simpleService = ChannelManagerSingleton.Instance.GetChannel<ISimpleService>();
			string result = string.Empty;
			try
			{
				/* Perform synchronous WCF call. */
				result = SynchronousChannelBroker.PerformAction<string, string>(
					simpleService.BeginGetGreeting, simpleService.EndGetGreeting, "there");

			}
			catch (Exception ex)
			{
				DisplayMessage(string.Format("Unable to communicate with server. {0} {1}", 
					ex.Message, ex.StackTrace));
			}
			DisplayGreeting(result);
		}

		void CallWcfSynchronously()
		{
			var channelFactory = new ChannelFactory<ISimpleService>("*");
			var simpleService = channelFactory.CreateChannel();
			var asyncResult = simpleService.BeginGetGreeting("Daniel", null, null);
			string greeting = null;
			try
			{
				greeting = simpleService.EndGetGreeting(asyncResult);
			}
			catch (Exception ex)
			{
				DisplayMessage(string.Format("Unable to communicate with server. {0} {1}",
					ex.Message, ex.StackTrace));
			}
			DisplayGreeting(greeting);
		}

		#region Displaying text
		void DisplayMessage(string message)
		{
			DisplayText(TextBlock_Message, message);
		}

		void DisplayGreeting(string message)
		{
			DisplayText(TextBlock_Greeting, message);
		}

		void DisplayText(TextBlock textBlock, string message)
		{
			if (Dispatcher.CheckAccess())
			{
				textBlock.Text = message;
			}
			else
			{
				Dispatcher.BeginInvoke(delegate
				{
					textBlock.Text = message;
				});
			}
		}
		#endregion

	}
}
