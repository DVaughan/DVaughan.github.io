﻿using DanielVaughan.Tests.ServiceReference1;

using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DanielVaughan.Tests
{
	[TestClass]
	public class SimpleServiceTests : SilverlightTest
	{
		[TestMethod]
		[Asynchronous]
		public void SimpleServiceShouldWork()
		{
			var client = new SimpleServiceClient();
			client.GetGreetingCompleted += ((sender, e) =>
			{
				Assert.AreEqual("Hi SimpleServiceClient", e.Result);
				TestComplete();
			});
			client.GetGreetingAsync("SimpleServiceClient");
		}

	}
}
