﻿using DanielVaughan.AI.NeuralNetworking;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace DanielVaughan.Tests
{
    
    
    /// <summary>
    ///This is a test class for NeuralInputGeneratorTest and is intended
    ///to contain all NeuralInputGeneratorTest Unit Tests
    ///</summary>
	[TestClass()]
	public class NeuralInputGeneratorTest
	{
    	/// <summary>
    	///Gets or sets the test context which provides
    	///information about and functionality for the current test run.
    	///</summary>
    	public TestContext TestContext { get; set; }

    	#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for GenerateInput
		///</summary>
		[TestMethod()]
		public void GenerateInputTest()
		{
			var target = new NeuralInputGenerator();
			double low = target.FalseLevel;
			double high = target.TrueLevel;

			object instance = new TestInput();

			double[] expected = new [] {low, low, low, low, low};
			double[] actual = target.GenerateInput(instance, false);

			AssertEquality(expected, actual);

			expected = new[] {high, high, low, low, low};
			instance = new TestInput {BaseName = "Test Name"};
			actual = target.GenerateInput(instance, true);
			AssertEquality(expected, actual);
		}

		void AssertEquality(double[] array1, double[] array2)
		{
			if (array1 == null)
			{
				Assert.IsNull(array2);
				return;
			}
			if (array2 == null)
			{
				Assert.IsNull(array1);
				return;
			}
			Assert.AreEqual(array1.Length, array2.Length);
			for (int i = 0; i < array1.Length; i++)
			{
				Assert.AreEqual(array1[i], array2[i], "Array values are not equal. Index: " + i);
			}
		}

		public class TestInput : TestInputBase
		{
			public string Name { get; set; }
			public bool TestBool { get; set; }
			public int TestInt { get; set; }
			public object TestObject1 { get; set; }
		}

		public class TestInputBase
		{
			public string BaseName { get; set; }
		}
	}
}
