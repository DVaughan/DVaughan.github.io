﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-11-03 23:11:46Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.ServiceModel.Activation;
using System.Threading;

namespace DanielVaughan.Silverlight.Examples.Web
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class SimpleService : ISimpleService
	{
		static int connectionCount;

		public string GetGreeting(string name)
		{
			Thread.Sleep(2000);
			return "Hi " + name;
		}

		public string InitiateConnection(string arbitraryIdentifier)
		{
			return (++connectionCount).ToString();
		}
	}
}
