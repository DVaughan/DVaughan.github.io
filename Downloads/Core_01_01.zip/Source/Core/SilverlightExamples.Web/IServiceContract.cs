﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-11-03 23:12:06Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.ComponentModel;
using System.ServiceModel;

namespace DanielVaughan.Silverlight.Examples.Web
{
	[ServiceContract(Namespace = Constants.ContractNamespace)]
	public interface IServiceContract
	{
		/// <summary>
		/// This method may perform any or no action. It is used to test
		/// the connection on a newly opened channel. It is much like the DoWork()
		/// or HelloWorld() method present on services to test for connectivity.
		/// Moreover, this method allows the ChannelManager 
		/// to negotiates the connection, and to fail early if there is a connectivity issue.
		/// </summary>
		/// <param name="arbitraryIdentifier">An arbitrary string identifier.</param>
		/// <returns>An arbitrary string value.</returns>
		[EditorBrowsable(EditorBrowsableState.Never)]
		[OperationContract]
		string InitiateConnection(string arbitraryIdentifier);
	}
}