﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-11-03 23:12:18Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.ServiceModel;

namespace DanielVaughan.Silverlight.Examples.Web
{
	[ServiceContract(Namespace = Constants.ContractNamespace)]
	public interface ISimpleService : IServiceContract
	{
		[OperationContract]
		string GetGreeting(string name);
	}
}
