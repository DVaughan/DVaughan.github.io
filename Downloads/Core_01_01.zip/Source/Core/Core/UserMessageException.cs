﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-04-10 18:52:20Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Runtime.Serialization;

using DanielVaughan.ComponentModel;

namespace DanielVaughan
{
	/// <summary>
	/// Default implementation of <see cref="IUserMessageProvider"/>.
	/// </summary>
	[Serializable]
	public class UserMessageException : ApplicationException, IUserMessageProvider
	{
		/// <summary>
		/// Gets or sets the localized user message, that is appropriate 
		/// for displaying to a user.
		/// </summary>
		/// <value>The user message.</value>
		public string UserMessage { get; protected set; }

		/// <summary>
		/// Gets a value indicating whether the UserMessage is <code>null</code>.
		/// </summary>
		/// <value><c>true</c> if the UserMessage is not <code>null</code>; 
		/// otherwise, <c>false</c>.</value>
		public bool UserMessagePresent
		{
			get
			{
				return UserMessage != null;
			}
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="UserMessageException"/> class.
		/// </summary>
		/// <param name="userMessage">The localized user message that is appropriate 
		/// for displaying to a user. Can be <code>null</code>.</param>
		/// <param name="developerMessage">The developer message that may contain 
		/// detailed information regarding the exception.</param>
		public UserMessageException(string developerMessage, string userMessage)
			: base(developerMessage)
		{
			UserMessage = userMessage;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="UserMessageException"/> class.
		/// </summary>
		/// <param name="userMessage">The localized user message that is appropriate 
		/// for displaying to a user. Can be <code>null</code>.</param>
		/// <param name="developerMessage">The developer message that may contain 
		/// detailed information regarding the exception.</param>
		/// <param name="innerException">The inner exception.</param>
		public UserMessageException(string developerMessage, string userMessage, Exception innerException)
			: base(developerMessage, innerException)
		{
			UserMessage = userMessage;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="UserMessageException"/> class.
		/// </summary>
		/// <param name="developerMessage">The developer message that may contain 
		/// detailed information regarding the exception.</param>
		public UserMessageException(string developerMessage)
			: base(developerMessage)
		{
			/* Intentionally left blank. */
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="UserMessageException"/> class.
		/// </summary>
		/// <param name="developerMessage">The developer message that may contain 
		/// detailed information regarding the exception.</param>
		/// <param name="innerException">The inner exception.</param>
		public UserMessageException(string developerMessage, Exception innerException)
			: base(developerMessage, innerException)
		{
			/* Intentionally left blank. */
		}

		public UserMessageException(SerializationInfo info, StreamingContext context) :
			base(info, context)
		{
			UserMessage = info.GetString("UserMessage");
		}

		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("UserMessage", UserMessage);
			base.GetObjectData(info, context);
		}

		public override string ToString()
		{
			string result;
			if (UserMessagePresent)
			{
				result = base.ToString();
			}
			else
			{
				result = string.Format("UserMessage: {0}, {1}", UserMessage, base.ToString());
			}
			return result;
		}
	}
}
