﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Daniel Vaughan Desktop CLR Core Library")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Daniel Vaughan")]
[assembly: AssemblyProduct("WpfCore")]
[assembly: AssemblyCopyright("Copyright © Daniel Vaughan 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("fccc16f0-6d8d-459b-8740-5bb06aac6087")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
/* 2 August 2009 */
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

[assembly: InternalsVisibleTo("DanielVaughan.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100bb5ac02a16983883207886153ffd32dcc614843010dd451eefae15b2055e3fba025dbea644c48a0b89a11a216b45a0c187bf8a7a1f62261d1cb5e23c7dbfde5c4c2c035a628fcdc6e70f040565a738c08848c4c345fe27d064bba9d4ab5ed0177d0c6a03a84d335edd818c712616d1c7cd4cefe4bf29c6ff697b5ab030541e9c")]
