﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-03-01 18:43:30Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.ComponentModel;
using System.ServiceModel;

namespace DanielVaughan.ServiceModel
{
	[ServiceContract(Namespace = OrganizationalConstants.ServiceContractNamespace)]
	/* TODO: [DV] comment. */
	public interface IServiceContract
	{
		/// <summary>
		/// This method may perform any or no action. It is used to test
		/// the connection on a newly opened channel. It is much like the DoWork()
		/// or HelloWorld() method present on service to test for connectivity.
		/// Moreover, this method allows the ChannelFactorySingleton 
		/// to negotiates the connection, and to fail early if there is a connectivity issue.
		/// </summary>
		/// <param name="arbitraryIdentifier">An arbitrary string identifier.</param>
		/// <returns>An arbitrary string value.</returns>
		[EditorBrowsable(EditorBrowsableState.Never)]
		[OperationContract]
		string InitiateConnection(string arbitraryIdentifier);
	}
}
