﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-03-01 18:43:44Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.ServiceModel;
using System.ServiceModel.Security;

namespace DanielVaughan.ServiceModel
{
	/// <summary>
	/// Use <code>IChannelManager</code> to create simplex and duplex WCF channels.
	/// </summary>
	public interface IChannelManager
	{
		/// <summary>
		/// Creates or retrieves a cached service channel.
		/// <example>
		/// var staticFactoryConfiguration = unityContainer.Configure<IStaticFactoryConfiguration>();
		///	Debug.Assert(staticFactoryConfiguration != null);
		///	if (staticFactoryConfiguration != null)
		///	{
		///		staticFactoryConfiguration.RegisterFactory<IYourService>(
		///			ChannelManagerSingleton.Instance.GetChannel<IYourService>);
		/// 
		///		/* Attempt to retrieve and use the service. */
		///		var yourService = UnitySingleton.Container.Resolve<IYourService>();
		///		yourService.DoSomething();
		/// }
		/// </example>
		/// </summary>
		/// <returns>A channel of the specified type.</returns>
		/// <exception cref="CommunicationException">Occurs if the service implements <see cref="IServiceContract"/>, 
		/// and the call to InitiateConnection results in a <code>CommunicationException</code></exception>
		/// <exception cref="SecurityNegotiationException">Occurs if the service implements <see cref="IServiceContract"/>, 
		/// and the call to InitiateConnection results in a <code>SecurityNegotiationException</code></exception>
		TService GetChannel<TService>();

		/// <summary>
		/// Creates a duplex service channel.
		/// <example>
		/// var channelManager = unityContainer.Resolve&lt;IChannelManager&gt;();
		/// var myService = channelManager.GetDuplexChannel<IMyService>(new MyServiceCallback());
		/// </example>
		/// </summary>
		/// <param name="callbackInstance">Is used to respond to server side me</param>
		/// <returns>A channel of the specified type.</returns>
		/// <exception cref="CommunicationException">Occurs if the service implements <see cref="IServiceContract"/>, 
		/// and the call to InitiateConnection results in a <code>CommunicationException</code></exception>
		/// <exception cref="SecurityNegotiationException">Occurs if the service implements <see cref="IServiceContract"/>, 
		/// and the call to InitiateConnection results in a <code>SecurityNegotiationException</code></exception>
		/// <exception cref="StudioException">Occurs if the specified <code>TCallback</code> 
		/// type is unable to be resolved by the specified unity container.</exception>
		TService GetDuplexChannel<TService>(object callbackInstance);
	}
}
