﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-02-22 13:31:35Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using log4net;

namespace DanielVaughan.ServiceModel
{
	/* TODO: [DV] Comment. */
	public abstract class ServiceContractBase : IServiceContract
	{
		static readonly ILog log = LogManager.GetLogger(typeof(ServiceContractBase));
		static int connectionCount;

		public virtual string InitiateConnection(string arbitraryIdentifier)
		{
			log.Info("Received initiate connection with arbitraryIdentifier: " + arbitraryIdentifier);
			return (++connectionCount).ToString();
		}
	}
}
