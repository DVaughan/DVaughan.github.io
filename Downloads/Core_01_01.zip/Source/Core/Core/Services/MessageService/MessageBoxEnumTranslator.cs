﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-04-25 14:52:16Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Windows;

namespace DanielVaughan.Services.Implementation
{
	public static class MessageBoxEnumTranslator
	{
		public static MessageBoxButton TranslateToMessageBoxButton(this MessageButton messageBoxButton)
		{
			return Translate(messageBoxButton);
		}

		public static MessageBoxButton Translate(MessageButton button)
		{
			switch (button)
			{
				case MessageButton.OK:
					return MessageBoxButton.OK;
				case MessageButton.OKCancel:
					return MessageBoxButton.OKCancel;
				case MessageButton.YesNo:
					return MessageBoxButton.YesNo;
				case MessageButton.YesNoCancel:
					return MessageBoxButton.YesNoCancel;
			}
			throw new InvalidOperationException("Unknown button type: " + button);
		}

		public static MessageBoxImage TranslateToMessageBoxButton(this MessageImage image)
		{
			return Translate(image);
		}

		public static MessageBoxImage Translate(MessageImage image)
		{
			switch (image)
			{
				case MessageImage.Asterisk:
					return MessageBoxImage.Asterisk;
				case MessageImage.Error:
					return MessageBoxImage.Error;
				case MessageImage.Exclamation:
					return MessageBoxImage.Exclamation;
				case MessageImage.Hand:
					return MessageBoxImage.Hand;
				case MessageImage.Information:
					return MessageBoxImage.Information;
				case MessageImage.None:
					return MessageBoxImage.None;
				case MessageImage.Question:
					return MessageBoxImage.Question;
				case MessageImage.Stop:
					return MessageBoxImage.Stop;
				case MessageImage.Warning:
					return MessageBoxImage.Warning;
			}
			throw new InvalidOperationException("Unknown image type: " + image);
		}

		public static MessageBoxResult TranslateToMessageBoxResult(this MessageResult messageResult)
		{
			return Translate(messageResult);
		}

		public static MessageBoxResult Translate(MessageResult messageResult)
		{
			switch (messageResult)
			{
				case MessageResult.Cancel:
					return MessageBoxResult.Cancel;
				case MessageResult.No:
					return MessageBoxResult.No;
				case MessageResult.None:
					return MessageBoxResult.None;
				case MessageResult.OK:
					return MessageBoxResult.OK;
				case MessageResult.Yes:
					return MessageBoxResult.Yes;
			}
			throw new InvalidOperationException("Unknown messageResult type: " + messageResult);
		}

		public static MessageResult TranslateToMessageBoxResult(this MessageBoxResult messageBoxResult)
		{
			return Translate(messageBoxResult);
		}

		public static MessageResult Translate(MessageBoxResult messageBoxResult)
		{
			switch (messageBoxResult)
			{
				case MessageBoxResult.Cancel:
					return MessageResult.Cancel;
				case MessageBoxResult.No:
					return MessageResult.No;
				case MessageBoxResult.None:
					return MessageResult.None;
				case MessageBoxResult.OK:
					return MessageResult.OK;
				case MessageBoxResult.Yes:
					return MessageResult.Yes;
			}
			throw new InvalidOperationException("Unknown messageBoxResult type: " + messageBoxResult);
		}
	}
}
