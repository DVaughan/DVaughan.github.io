﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-04-11 20:01:19Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.Threading;
using System.Windows;

using DanielVaughan.Gui;

namespace DanielVaughan.Services.Implementation
{
	/// <summary>
	/// WPF implementation of the <see cref="IMessageService"/>.
	/// </summary>
	public class MessageService : MessageServiceBase
	{
		public override MessageResult ShowCustomDialog(string message, string caption,
			MessageButton messageButton, MessageImage messageImage, 
			MessageImportance? importanceThreshold, string details)
		{
			/* If the importance threshold has been specified 
			 * and it's less than the minimum level required (the filter level) 
			 * then we don't show the message. */
			if (importanceThreshold.HasValue && importanceThreshold.Value < MinumumImportance)
			{
				return MessageResult.OK;
			}

			if (MainWindow.Dispatcher.CheckAccess())
			{	/* We are on the UI thread, and hence no need to invoke the call.*/
				var messageBoxResult = MessageBox.Show(MainWindow, message, caption, 
					messageButton.TranslateToMessageBoxButton(), 
					messageImage.TranslateToMessageBoxButton());
				return messageBoxResult.TranslateToMessageBoxResult();
			}

			MessageResult result = MessageResult.OK; /* Satisfy compiler with default value. */
			MainWindow.Dispatcher.Invoke((ThreadStart)delegate
			{
				var messageBoxResult = MessageBox.Show(MainWindow, message, caption, 
					messageButton.TranslateToMessageBoxButton(), 
					messageImage.TranslateToMessageBoxButton());
				result = messageBoxResult.TranslateToMessageBoxResult();
			});

			return result;
		}

		static Window MainWindow
		{
			get
			{
				return UnitySingleton.Container.Resolve<IMainWindow>() as Window;
			}
		}
	}
}
