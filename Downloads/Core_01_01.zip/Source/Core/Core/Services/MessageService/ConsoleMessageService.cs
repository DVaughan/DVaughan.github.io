﻿//#region File and License Information
///*
//<File>
//	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
//	<License see="prj:///Documentation/License.txt"/>
//	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
//	<CreationDate>2009-04-11 20:09:38Z</CreationDate>
//	<LastSubmissionDate>$Date: $</LastSubmissionDate>
//	<Version>$Revision: $</Version>
//</File>
//*/
//#endregion
//
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Windows;
//
//using DanielVaughan.Resources;
//
//namespace DanielVaughan.Services.Implementation
//{
//	public class ConsoleMessageService : MessageService
//	{
//		public override MessageBoxResult ShowCustomDialog(string message, string caption, 
//			MessageBoxButton messageBoxButton, MessageBoxImage messageBoxImage, MessageImportance? importanceThreshold)
//		{
//			/* If the importance threshold has been specified and it's less than the minimum level required (the filter level) 
//			 * then we don't show the message. */
//			if (importanceThreshold.HasValue && importanceThreshold.Value < MinumumImportance)
//			{
//				return MessageBoxResult.OK;
//			}
//	
//			Console.WriteLine(message);
//			MessageBoxResult result = MessageBoxResult.OK; /* Satisfy compiler with default value. */
//
//			List<KeyValuePair<int, string>> menuOptions;
//			int selectedOption;
//
//			switch (messageBoxButton)
//			{
//				case MessageBoxButton.OKCancel:
//					menuOptions = new List<KeyValuePair<int, string>>
//					                  	{
//					                  		new KeyValuePair<int, string>(1, "Ok"), 
//											new KeyValuePair<int, string>(2, "Cancel")
//					                  	};
//					selectedOption = GetSelectedOption(menuOptions);
//					result = selectedOption == 1 ? MessageBoxResult.OK : MessageBoxResult.Cancel;
//					break;
//				case MessageBoxButton.YesNo:
//					menuOptions = new List<KeyValuePair<int, string>>
//					                  	{
//					                  		new KeyValuePair<int, string>(1, "Yes"), 
//											new KeyValuePair<int, string>(2, "No")
//					                  	};
//					selectedOption = GetSelectedOption(menuOptions);
//					result = selectedOption == 1 ? MessageBoxResult.Yes : MessageBoxResult.No;
//					break;
//				case MessageBoxButton.YesNoCancel:
//					menuOptions = new List<KeyValuePair<int, string>>
//					                  	{
//					                  		new KeyValuePair<int, string>(1, "Yes"), 
//											new KeyValuePair<int, string>(2, "No"),
//											new KeyValuePair<int, string>(3, "Cancel")
//					                  	};
//					selectedOption = GetSelectedOption(menuOptions);
//					switch (selectedOption)
//					{
//						case 1:
//							result = MessageBoxResult.Yes;
//							break;
//						case 2:
//							result = MessageBoxResult.No;
//							break;
//						default:
//							result = MessageBoxResult.Cancel;
//							break;
//					}
//					break;
//				case MessageBoxButton.OK:
//					result = MessageBoxResult.OK;
//					break;
//			}
//
//			return result;
//		}
//
//		static int GetSelectedOption(List<KeyValuePair<int, string>> menuOptions)
//		{
//			var validValues = (from menuOption in menuOptions select menuOption.Key).ToList();
//			do
//			{
//				foreach (var menuItem in menuOptions)
//				{
//					string menuLine = string.Format(StringResources.Services_ConsoleMessageService_MenuItemFormat, 
//						menuItem.Key, menuItem.Value);
//					Console.WriteLine(menuLine);
//				}
//				string line = Console.ReadLine();
//				if (line != null)
//				{
//					int result;
//					if (int.TryParse(line, out result))
//					{
//						if (validValues.Contains(result))
//						{
//							return result;
//						}
//					}
//				}
//				Console.WriteLine("Invalid input."); 
//			} while (true);
//		}
//	}
//}
