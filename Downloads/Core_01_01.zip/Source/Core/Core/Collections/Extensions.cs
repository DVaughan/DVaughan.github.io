﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2008-12-28 19:52:25Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.Collections.Generic;

namespace DanielVaughan.Collections
{
	public static class Extensions
	{
		public static int GetIndexOfGreatest(this IEnumerable<double> output)
		{
			ArgumentValidator.AssertNotNull(output, "output");
			int result = -1;
			int count = 0;
			double highest = -1;
			foreach (var d in output)
			{
				if (d > highest)
				{
					highest = d;
					result = count;
				}
				count++;
			}
			return result;
		}
	}
}
