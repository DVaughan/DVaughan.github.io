﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-03-29 23:31:47Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using Microsoft.Practices.Unity;

namespace DanielVaughan
{
	/// <summary>
	/// Helper class to resolve a Unity container 
	/// that must be initialized once.
	/// </summary>
	public class UnitySingleton
	{
		static IUnityContainer unityContainer;
		static readonly object unityContainerLock = new object();
		//static bool initialized;

		#region Singleton implementation

		UnitySingleton()
		{
		}

//		public static UnitySingleton Instance
//		{
//			get
//			{
//				return Nested.instance;
//			}
//		}

		class Nested
		{
			// Explicit static constructor to tell C# compiler
			// not to mark type as beforefieldinit
			static Nested()
			{
			}

			internal static readonly UnitySingleton instance = new UnitySingleton();
		}

		#endregion
 

		/// <summary>
		/// Gets the unity container that was attached 
		/// when the UnitySingleton was Initialized.
		/// </summary>
		/// <value>The global unity container.</value>
		public static IUnityContainer Container
		{
			get
			{
				if (unityContainer == null)
				{
					lock (unityContainerLock)
					{
						if (unityContainer == null)
						{
							unityContainer = new UnityContainer();
						}
					}
				}
				return unityContainer;
			}
		}

		/// <summary>
		/// Initializes the specified global container.
		/// Expects a configuration section called unity.
		/// </summary>
		/// <param name="globalContainer">The global container.</param>
		/// <exception cref="InvalidOperationException">
		/// Occurs if this method was previously called 
		/// with a different <code>IUnityContainer</code> instance.</exception>
		[EditorBrowsable(EditorBrowsableState.Never)]
		[MethodImpl(MethodImplOptions.Synchronized)]
		public static void Initialize(IUnityContainer globalContainer)
		{
			unityContainer = globalContainer;
		}
	}
}
