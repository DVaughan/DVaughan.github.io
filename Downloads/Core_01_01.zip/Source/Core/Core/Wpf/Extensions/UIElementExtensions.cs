﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-01-04 15:16:08Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System.Windows;

namespace DanielVaughan.Wpf
{
	public static class UIElementExtensions
	{
		public static void ForceFocus(this UIElement uiElement)
		{
			ArgumentValidator.AssertNotNull(uiElement, "uiElement");
			FocusForcer.Focus(uiElement);
		}

		public static Window GetWindow(this DependencyObject dependencyObject)
		{
			ArgumentValidator.AssertNotNull(dependencyObject, "dependencyObject");

			var parent = LogicalTreeHelper.GetParent(dependencyObject);

			while (parent != null && !(parent is Window))
			{
				parent = LogicalTreeHelper.GetParent(parent);
			}

			return parent as Window;
		}
	}
}
