﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-02-08 17:02:02Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace DanielVaughan.AI.NeuralNetworking
{
	[Serializable]
	public class TrainingSet
	{
		internal IEnumerable<LayerStimulus> Inputs { get; private set; }
		internal IEnumerable<LayerStimulus> Outputs { get; private set; }
		internal Dictionary<LayerStimulus, LayerStimulus> InputOutputDictionary { get; private set; }

		public TrainingSet(TrainingSet trainingSet)
		{
			ArgumentValidator.AssertNotNull(trainingSet, "trainingSet");
			InputOutputDictionary = new Dictionary<LayerStimulus, LayerStimulus>(trainingSet.InputOutputDictionary);
		}

		public TrainingSet(IList<LayerStimulus> inputs, IList<LayerStimulus> outputs)
		{
			ArgumentValidator.AssertNotNull(inputs, "inputs");
			ArgumentValidator.AssertNotNull(outputs, "outputs");

			var tempInputList = inputs.ToList();
			var tempOutputList = outputs.ToList();
			if (tempInputList.Count != tempOutputList.Count)
			{
				throw new ArgumentException(string.Format("Inputs count should equal Outputs count. Inputs count: {0}, Outputs count: {1}",
					tempInputList.Count, tempOutputList.Count));
			}
			Inputs = tempInputList;
			Outputs = tempOutputList;

			InputOutputDictionary = new Dictionary<LayerStimulus, LayerStimulus>();
			int count = 0;
			foreach (var input in inputs)
			{
				InputOutputDictionary.Add(input, outputs[count++]);
			}
		}

		public TrainingSet(IEnumerable<KeyValuePair<LayerStimulus, LayerStimulus>> inputsOutputMappings)
		{
			ArgumentValidator.AssertNotNull(inputsOutputMappings, "inputsOutputMappings");
			Inputs = new List<LayerStimulus>();
			Outputs = new List<LayerStimulus>();
			InputOutputDictionary = new Dictionary<LayerStimulus, LayerStimulus>();

			foreach (var pair in inputsOutputMappings)
			{
				InputOutputDictionary[pair.Key] = pair.Value;
			}
		}
	}
}
