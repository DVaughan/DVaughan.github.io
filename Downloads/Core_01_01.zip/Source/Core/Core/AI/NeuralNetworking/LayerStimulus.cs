﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License see="prj:///Documentation/License.txt"/>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-02-08 17:01:50Z</CreationDate>
	<LastSubmissionDate>$Date: $</LastSubmissionDate>
	<Version>$Revision: $</Version>
</File>
*/
#endregion

using System;
using System.Linq;

namespace DanielVaughan.AI.NeuralNetworking
{
	[Serializable]
	public struct LayerStimulus
	{
		internal double[] Data { get; private set; }

		public LayerStimulus(double[] data) : this()
		{
			ArgumentValidator.AssertNotNull(data, "data");
			toStringResultLock = new object();
			Data = data;
		}

		public override bool Equals(object obj)
		{
			return obj is LayerStimulus && Equals((LayerStimulus)obj);
		}

		bool Equals(LayerStimulus layerStimulus)
		{
			if (layerStimulus.Data.Length != Data.Length)
			{
				return false;
			}
			for (int i = 0; i < Data.Length; i++)
			{
				if (layerStimulus.Data[i] != Data[i])
				{
					return false;
				}
			}
			return true;
		}


		public override int GetHashCode()
		{
			return ToString().GetHashCode();
		}

		string toStringResult;
		readonly object toStringResultLock;

		public override string ToString()
		{
			if (toStringResult == null)
			{
				lock (toStringResultLock)
				{
					var arrayAsStrings = from d in Data
					                     select d.ToString();
					toStringResult = string.Join(", ", arrayAsStrings.ToArray());
				}
			}
			return toStringResult;

		}
	}
}
