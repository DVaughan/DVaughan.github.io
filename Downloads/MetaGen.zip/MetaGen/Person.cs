﻿using System.ComponentModel;

namespace DanielVaughan.MetaGen.Demo
{
	internal class Person : INotifyPropertyChanged
	{
		string name;

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
				OnPropertyChanged(Metadata.PersonMetadata.MemberNames.Name);
			}
		}

		string address;

		public string Address
		{
			get
			{
				return address;
			}
			set
			{
				address = value;
				OnPropertyChanged(Metadata.PersonMetadata.MemberNames.Address);
			}
		}

		int age;

		public int Age
		{
			get
			{
				return age;
			}
			set
			{
				age = value;
				OnPropertyChanged(Metadata.PersonMetadata.MemberNames.Age);
			}
		}

		protected virtual void OnPropertyChanged(string propertyName)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}


		public event PropertyChangedEventHandler PropertyChanged;
	}
}