﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DanielVaughan.MetaGen.Demo.Folder1
{
	interface Folder1Interface
	{
		string Foo { get; }
	}
}
