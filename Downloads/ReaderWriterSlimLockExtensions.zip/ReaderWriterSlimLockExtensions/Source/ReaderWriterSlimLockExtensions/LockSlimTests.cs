﻿using System.Collections.Generic;

using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Threading;

using DanielVaughan.Threading;

namespace ReaderWriterSlimLockExtensions
{
	[TestClass]
	public class LockSlimTests : SilverlightTest
	{
		readonly static List<string> sharedList = new List<string>();

		[TestMethod]
		public void ExtensionsShouldPerformActions()
		{
			ReaderWriterLockSlim lockSlim = new ReaderWriterLockSlim();

			string item1 = "test";

			//	Rather than this code:
			//			try
			//			{
			//				lockSlim.EnterWriteLock();
			//				sharedList.Add(item1);
			//			}
			//			finally
			//			{
			//				lockSlim.ExitWriteLock();
			//			}
			//	We can write this one liner:
			lockSlim.PerformUsingWriteLock(() => sharedList.Add(item1));

			//	Rather than this code:
			//			string result;
			//			try
			//			{
			//				lockSlim.EnterReadLock();
			//				result = sharedList[0];
			//			}
			//			finally
			//			{
			//				lockSlim.ExitReadLock();
			//			}
			//	We can write this one liner:
			string result = lockSlim.PerformUsingReadLock(() => sharedList[0]);

			Assert.AreEqual(item1, result);

			string item2 = "test2";

			//	Rather than this code:
			//			try
			//			{
			//				lockSlim.EnterUpgradeableReadLock();
			//				if (!sharedList.Contains(item2))
			//				{
			//					try
			//					{
			//						lockSlim.EnterWriteLock();
			//						sharedList.Add(item2);
			//					}
			//					finally
			//					{
			//						lockSlim.ExitWriteLock();
			//					}
			//				}
			//			}
			//			finally
			//			{
			//				lockSlim.ExitUpgradeableReadLock();
			//			}
			//	We can write this:
			lockSlim.PerformUsingUpgradeableReadLock(() => 
				{
					if (!sharedList.Contains(item2))
					{
						lockSlim.PerformUsingWriteLock(() => sharedList.Add(item2));
					}
				});

			//	Rather than this code:
			//			try
			//			{
			//				lockSlim.EnterReadLock();
			//				result = sharedList[1];
			//			}
			//			finally
			//			{
			//				lockSlim.ExitReadLock();
			//			}
			//	We can write this:
			result = lockSlim.PerformUsingReadLock(() => sharedList[1]);

			Assert.AreEqual(item2, result);
		}

	}


}
