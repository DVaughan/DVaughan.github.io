﻿using Android.App;
namespace AndroidResxT4
{
	public class AppResources {
public static string Greeting { get { return Application.Context.GetString(Resource.String.Greeting); }}
}}
