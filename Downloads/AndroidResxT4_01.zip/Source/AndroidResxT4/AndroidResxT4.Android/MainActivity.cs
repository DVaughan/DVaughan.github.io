﻿using System;

using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace AndroidResxT4.Android
{
	[Activity(Label = "AndroidResxT4", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		bool localeToggled;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			SetContentView(Resource.Layout.Main);

			AttachView();
		}

		void HandleButtonClick(object sender, EventArgs e)
		{
			SetLocale(!localeToggled ? "fr" : "en");
			localeToggled = !localeToggled;

			Console.WriteLine(AppResources.Greeting);
		}

		void AttachView()
		{
			Button button = FindViewById<Button>(Resource.Id.MyButton);
			button.Click -= HandleButtonClick;
			button.Click += HandleButtonClick;
		}

		void DetachView()
		{
			Button button = FindViewById<Button>(Resource.Id.MyButton);
			button.Click -= HandleButtonClick;
		}

		void SetLocale(string languageCode)
		{
			Resources resources = Resources;
			Configuration configuration = resources.Configuration;
			configuration.Locale = new Java.Util.Locale(languageCode);
			DisplayMetrics displayMetrics = resources.DisplayMetrics;
			resources.UpdateConfiguration(configuration, displayMetrics);

			DetachView();

			SetContentView(Resource.Layout.Main);

			AttachView();
		}
	}
}

