﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using DanielVaughan.MetaGen.Demo;

namespace SilverlightClr
{
	public partial class MainPage
	{
		bool stateToggled;

		public MainPage()
		{
			InitializeComponent();
		}

		void Button_ChangeClick(object sender, RoutedEventArgs e)
		{
			var person = (Person)Resources["Person"];
			if (stateToggled)
			{
				person.Name = "Pam";
				person.Address = new Address {StreetLine = "USA"};
				person.Age = 22;
			}
			else
			{
				person.Name = "Jim";
				person.Address = new Address { StreetLine = "Australia" }; 
				person.Age = 39;
			}
			stateToggled = !stateToggled;
		}
	}
}
