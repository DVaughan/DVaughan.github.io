﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq.Expressions;

using DanielVaughan.MetaGen.Demo.Metadata;

namespace DanielVaughan.MetaGen.Demo
{
	public class Person : IPerson, INotifyPropertyChanged
	{
		string name;

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
				OnPropertyChanged(PersonMetadata.Name);
			}
		}

		Address address;

		public Address Address
		{
			get
			{
				return address;
			}
			set
			{
				address = value;
				OnPropertyChanged(PersonMetadata.Address);
			}
		}

		int age;

		public int Age
		{
			get
			{
				return age;
			}
			set
			{
				age = value;
				OnPropertyChanged(PersonMetadata.Age);
			}
		}

		public void ObfuscationTest()
		{
			/* Intentionally left blank. */
		}

		protected virtual void OnPropertyChanged(string propertyName)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}
        
		public event PropertyChangedEventHandler PropertyChanged;

//		public static bool operator ==(Person leftPerson, Person rightPerson)
//		{
//			/* This is merely for demonstration purposes. */
//			return true;
//		}
//
//		public static bool operator !=(Person leftPerson, Person rightPerson)
//		{
//			return !(leftPerson == rightPerson);
//		}
	}

	public class Address
	{
		public string StreetLine { get; set; }
	}
}