﻿#region File and License Information
/*
<File>
	<Copyright>Copyright © 2007, Daniel Vaughan. All rights reserved.</Copyright>
	<License>
		Redistribution and use in source and binary forms, with or without
		modification, are permitted provided that the following conditions are met:
			* Redistributions of source code must retain the above copyright
			  notice, this list of conditions and the following disclaimer.
			* Redistributions in binary form must reproduce the above copyright
			  notice, this list of conditions and the following disclaimer in the
			  documentation and/or other materials provided with the distribution.
			* Neither the name of the <organization> nor the
			  names of its contributors may be used to endorse or promote products
			  derived from this software without specific prior written permission.

		THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
		EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
		DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
		DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
		(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
		LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
		ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
		(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
		SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	</License>
	<Owner Name="Daniel Vaughan" Email="dbvaughan@gmail.com"/>
	<CreationDate>2009-11-07 13:33:41Z</CreationDate>
</File>
*/
#endregion

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Markup;

namespace DanielVaughan.MetaGen.Demo
{
	/// <summary>
	/// Allows a set of property path strings to be concatenates 
	/// into a <see cref="PropertyPath"/> instance.
	/// </summary>
	[MarkupExtensionReturnType(typeof(PropertyPath))]
	public class JoinPathExtension : MarkupExtension
	{
		readonly List<string> members = new List<string>(); 

		public JoinPathExtension()
		{
			/* Intentionally left blank. */
		}

		public JoinPathExtension(string member0)
		{
			if (member0 == null)
			{
				throw new ArgumentNullException("member0");
			}
			members.Add(member0);
		}

		public JoinPathExtension(string member0, string member1)
			: this(member0)
		{
			if (member1 == null)
			{
				throw new ArgumentNullException("member1");
			}
			members.Add(member1);
		}

		public JoinPathExtension(string member0, string member1, string member2)
			: this(member0, member1)
		{
			if (member2 == null)
			{
				throw new ArgumentNullException("member2");
			}
			members.Add(member2);
		}
        
		public JoinPathExtension(string member0, string member1, string member2, string member3) 
			: this(member0, member1, member2)
		{
			if (member3 == null)
			{
				throw new ArgumentNullException("member3");
			}
			members.Add(member3);
		}

		public JoinPathExtension(string member0, string member1, string member2, string member3, string member4)
			: this(member0, member1, member2, member3)
		{
			if (member4 == null)
			{
				throw new ArgumentNullException("member4");
			}
			members.Add(member4);
		}

		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			var path = string.Join(".", members.ToArray());
			var result = new PropertyPath(path);
			return result;
		}

		void SetMember(int index, string value)
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (members.Count < index + 1)
			{
				members.Add(value);
				return;
			}
			members[index] = value;
		}

		#region Named member properties
		[ConstructorArgument("member0")]
		public string Member0
		{
			get
			{
				return members[0];
			}
			set
			{
				SetMember(0, value);
			}
		}

		public string Member1
		{
			get
			{
				return members[1];
			}
			set
			{
				SetMember(1, value);
			}
		}

		public string Member2
		{
			get
			{
				return members[2];
			}
			set
			{
				SetMember(2, value);
			}
		}

		public string Member3
		{
			get
			{
				return members[3];
			}
			set
			{
				SetMember(3, value);
			}
		}

		public string Member4
		{
			get
			{
				return members[4];
			}
			set
			{
				SetMember(4, value);
			}
		}

		public string Member5
		{
			get
			{
				return members[5];
			}
			set
			{
				SetMember(5, value);
			}
		}

		public string Member6
		{
			get
			{
				return members[6];
			}
			set
			{
				SetMember(6, value);
			}
		}

		public string Member7
		{
			get
			{
				return members[7];
			}
			set
			{
				SetMember(7, value);
			}
		}

		public string Member8
		{
			get
			{
				return members[8];
			}
			set
			{
				SetMember(8, value);
			}
		}

		public string Member9
		{
			get
			{
				return members[9];
			}
			set
			{
				SetMember(9, value);
			}
		}

		public string Member10
		{
			get
			{
				return members[10];
			}
			set
			{
				SetMember(10, value);
			}
		}
		#endregion

		#region Alternate approaches
		//		public JoinPathExtension(IList members)
		//		{
		//			if (members == null)
		//			{
		//				throw new ArgumentNullException("memberList");
		//			}
		//			foreach (object item in members)
		//			{
		//				this.members.Add(item.ToString());
		//			}
		//		}
		//
		//		public JoinPathExtension(string members)
		//		{
		//			if (members == null)
		//			{
		//				throw new ArgumentNullException("memberList");
		//			}
		//
		//			this.members = members.Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries).ToList();
		//
		//			if (this.members.Count == 0)
		//			{
		//				throw new ArgumentException("No member paths found.");
		//			}
		//		}
		//
		//		[ConstructorArgument("members")]
		//		public List<string> Members
		//		{
		//			get
		//			{
		//				return members;
		//			}
		//			set
		//			{
		//				members.Clear();
		//				members.AddRange(value);
		//			}
		//		}
		#endregion
	}
}
