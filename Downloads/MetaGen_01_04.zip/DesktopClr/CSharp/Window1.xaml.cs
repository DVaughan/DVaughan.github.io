﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DanielVaughan.MetaGen.Demo
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1
	{
		bool stateToggled;

		public Window1()
		{
			InitializeComponent();
			PersonPanel.DataContext = new Person
			                          	{
			                          		Name = "Alan", 
											Address = new Address {StreetLine = "Uk"}, 
											Age = 21
			                          	};

			/* We output the name of the 'ObfuscationTest' method name. 
			 * This will be 'ObfuscationTest' unless obfuscated. */
			NamePropertyBlock.Text = Metadata.PersonMetadata.ObfuscationTest;

			var list = new List<Person> {	new Person {Name = "Pam", Address = new Address {StreetLine = "USA"}, Age = 22}, 
											new Person {Name = "Jim", Address = new Address {StreetLine = "Australia"}, Age = 39},
											new Person {Name = "Alex", Address = new Address {StreetLine = "Switzerland"}, Age = 47}};
			listBox.ItemsSource = list;

			//LoadResourceExample();
		}

		void Button_ChangeClick(object sender, RoutedEventArgs e)
		{
			var person = (Person)PersonPanel.DataContext;//(Person)Resources["Person"];
			if (stateToggled)
			{
				person.Name = "Pam";
				person.Address = new Address {StreetLine = "USA"};
				person.Age = 22;
			}
			else
			{
				person.Name = "Jim";
				person.Address = new Address { StreetLine = "Australia" };
				person.Age = 39;
			}
			stateToggled = !stateToggled;
		}

		void LoadResourceExample()
		{
			try
			{
				Uri uri = new Uri(CSharpDesktopClrDemo.XamlMetadata.Folder1.Folder2.Metadata.UserControl1XamlMetadata.XamlPackUri, UriKind.Relative);
				var control = System.Windows.Application.LoadComponent(uri) as DanielVaughan.MetaGen.Demo.Folder1.Folder2.UserControl1;
			}
			catch (Exception ex)
			{
			}
		}
	}
}
