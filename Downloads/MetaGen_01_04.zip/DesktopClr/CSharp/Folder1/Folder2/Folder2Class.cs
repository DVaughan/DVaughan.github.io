﻿
namespace DanielVaughan.MetaGen.Demo.Folder1.Folder2
{
	class Folder2Class
	{
		public string Foo { get; set; }

		class Folder2InnerClass
		{
			public string Foo2 { get; set; }
		}
	}
}
