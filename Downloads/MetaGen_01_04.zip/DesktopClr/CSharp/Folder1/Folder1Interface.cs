﻿
namespace DanielVaughan.MetaGen.Demo.Folder1
{
	interface Folder1Interface
	{
		string Foo { get; }
	}
}
