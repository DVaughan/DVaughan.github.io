﻿
namespace DanielVaughan.MetaGen.Demo.Folder1
{
	public static class Folder1StaticClass
	{
		public const string StringConstant = "foo";

		public static string StringStaticProperty
		{
			get
			{
				return "bah";
			}
		}
	}
}
