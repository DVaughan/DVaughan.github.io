
public class SimpleClass
{
		public int Property0 { get; set; }
		public int Property1 { get; set; }
		public int Property2 { get; set; }
			
}