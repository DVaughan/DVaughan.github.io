﻿Imports System.ComponentModel

Public Class Person
	Implements IPerson, INotifyPropertyChanged
	' Events
	Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

	' Methods
	Public Sub ObfuscationTest()
	End Sub

	Protected Overridable Sub OnPropertyChanged(ByVal propertyName As String)
		RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
	End Sub


	' Properties
	Public Property Address() As String Implements IPerson.Address 
		Get
			Return _address
		End Get
		Set(ByVal value As String)
			_address = value
			OnPropertyChanged(PersonMetadata.Address)
		End Set
	End Property

	Public Property Age() As Integer Implements IPerson.Age
		Get
			Return _age
		End Get
		Set(ByVal value As Integer)
			_age = value
			OnPropertyChanged(PersonMetadata.Age)
		End Set
	End Property

	Public Property Name() As String Implements IPerson.Name
		Get
			Return _name
		End Get
		Set(ByVal value As String)
			_name = value
			OnPropertyChanged(PersonMetadata.Name)
		End Set
	End Property

	' Just for demo
	Public Shared Operator =(ByVal personLeft As Person, ByVal personRight As Person) As Boolean
		Return True
	End Operator

	' Just for demo
	Public Shared Operator <>(ByVal personLeft As Person, ByVal personRight As Person) As Boolean
		Return True
	End Operator

	' Fields
	Private _address As String
	Private _age As Integer
	Private _name As String
End Class



