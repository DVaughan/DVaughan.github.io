﻿Imports System.Windows.Markup

Public Class JoinPathExtension
	Inherits MarkupExtension
	' Methods
	Public Sub New()
		Me.members = New List(Of String)
	End Sub

	Public Sub New(ByVal memberList As String())
		Me.members = New List(Of String)
		If (memberList Is Nothing) Then
			Throw New ArgumentNullException("memberList")
		End If
		Me.members.AddRange(memberList)
	End Sub

	Public Sub New(ByVal member1 As String)
		Me.members = New List(Of String)
		If (member1 Is Nothing) Then
			Throw New ArgumentNullException("member1")
		End If
		Me.members.Add(member1)
	End Sub

	Public Sub New(ByVal member1 As String, ByVal member2 As String)
		Me.New(member1)
		If (member2 Is Nothing) Then
			Throw New ArgumentNullException("member2")
		End If
		Me.members.Add(member2)
	End Sub

	Public Sub New(ByVal member1 As String, ByVal member2 As String, ByVal member3 As String)
		Me.New(member1, member2)
		If (member3 Is Nothing) Then
			Throw New ArgumentNullException("member3")
		End If
		Me.members.Add(member3)
	End Sub

	Public Sub New(ByVal member1 As String, ByVal member2 As String, ByVal member3 As String, ByVal member4 As String)
		Me.New(member1, member2, member3)
		If (member4 Is Nothing) Then
			Throw New ArgumentNullException("member4")
		End If
		Me.members.Add(member4)
	End Sub

	Public Sub New(ByVal member1 As String, ByVal member2 As String, ByVal member3 As String, ByVal member4 As String, ByVal member5 As String)
		Me.New(member1, member2, member3, member4)
		If (member5 Is Nothing) Then
			Throw New ArgumentNullException("member5")
		End If
		Me.members.Add(member5)
	End Sub

	Public Overrides Function ProvideValue(ByVal serviceProvider As IServiceProvider) As Object
		Return New PropertyPath(String.Join(".", Me.members.ToArray), New Object(0 - 1) {})
	End Function


	' Properties
	<ConstructorArgument("member1")> _
	Public Property Member() As String
		Get
			Return Me.members.Item(0)
		End Get
		Set(ByVal value As String)
			If (value Is Nothing) Then
				Throw New ArgumentNullException("value")
			End If
			If (Me.members.Count < 1) Then
				Me.members.Add(value)
			Else
				Me.members.Item(0) = value
			End If
		End Set
	End Property

	<ConstructorArgument("member2")> _
	Public Property Member2() As String
		Get
			Return Me.members.Item(1)
		End Get
		Set(ByVal value As String)
			If (value Is Nothing) Then
				Throw New ArgumentNullException("value")
			End If
			If (Me.members.Count < 2) Then
				Me.members.Add(value)
			Else
				Me.members.Item(1) = value
			End If
		End Set
	End Property


	' Fields
	Private ReadOnly members As List(Of String)
End Class

