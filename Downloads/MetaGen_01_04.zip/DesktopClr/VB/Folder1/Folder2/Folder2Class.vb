﻿Namespace Folder1.Folder2
	Friend Class Folder2Class
		Dim _foo As String

		Public Property Foo() As String
			Get
				Return _foo
			End Get
			Set(ByVal value As String)
				_foo = value
			End Set
		End Property

		Class Folder2InnerClass
			Dim _foo2 As String

			Public Property Foo2() As String
				Get
					Return _foo2
				End Get
				Set(ByVal value As String)
					_foo2 = value
				End Set
			End Property
		End Class
	End Class
End Namespace