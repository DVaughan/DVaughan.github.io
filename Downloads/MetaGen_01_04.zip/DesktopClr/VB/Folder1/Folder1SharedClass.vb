﻿Namespace Folder1
	Public Class Folder1SharedClass
		' Properties
		Public Shared ReadOnly Property StringStaticProperty() As String
			Get
				Return "bah"
			End Get
		End Property


		' Fields
		Public Const StringConstant As String = "foo"
	End Class
End Namespace