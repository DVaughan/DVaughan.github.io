﻿Namespace Folder1
	Friend Interface Folder1Interface
		' Properties
		ReadOnly Property Foo() As String
	End Interface
End Namespace