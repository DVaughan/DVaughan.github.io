
public Class SimpleClass
		Dim field1 As Integer 
		Dim field2 As Integer 
		Dim field3 As Integer 
			
End Class