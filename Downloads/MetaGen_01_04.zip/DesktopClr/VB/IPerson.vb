﻿Friend Interface IPerson
	' Properties
	Property Address() As String
	Property Age() As Integer
	Property Name() As String
End Interface

