﻿Class Window1
	Dim stateToggled As Boolean

	Public Sub New()
		Me.InitializeComponent()
		Dim people As New List(Of Person)
		Dim person1 As New Person
		person1.Name = "Alan"
		person1.Address = "Uk"
		person1.Age = 15
		people.Add(person1)
		Dim person2 As New Person
		person2.Name = "Pam"
		person2.Address = "USA"
		person2.Age = 28
		people.Add(person2)
		Dim person3 As New Person
		person3.Name = "Alex"
		person3.Address = "Switzerland"
		person3.Age = 46
		people.Add(person3)
		listBox.ItemsSource = people
	End Sub


	Private Sub Button_ChangeClick(ByVal sender As Object, ByVal e As RoutedEventArgs)
		Dim person As Person = DirectCast(Resources("Person"), Person)

		If (stateToggled) Then
			person.Name = "Pam"
			person.Address = "USA"
			person.Age = 22
		Else
			person.Name = "Jim"
			person.Address = "Australia"
			person.Age = 39
		End If

		stateToggled = Not stateToggled

	End Sub
End Class
