﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;

using SingleApp;

namespace SingleApp2
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		SingletonApplicationEnforcer mediator = new SingletonApplicationEnforcer(DoSomethingWithArgs);

		static void DoSomethingWithArgs(IEnumerable<string> args)
		{
			foreach (var arg in args)
			{
				Debug.WriteLine("Arg received:" + arg);
			}
		}

		public App()
		{
			if (mediator.ShouldApplicationExit())
			{
				Shutdown();
			}
		}

	}
}
