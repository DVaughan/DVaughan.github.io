﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;

namespace SingleApp
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		readonly SingletonApplicationEnforcer enforcer = new SingletonApplicationEnforcer(DisplayArgs);

		public App()
		{
			if (enforcer.ShouldApplicationExit())
			{
				this.Shutdown();
			}
		}

		public static void DisplayArgs(IEnumerable<string> args)
		{
			foreach (var arg in args)
			{
				string message = string.Format("Received arg: {0}", arg);
				Debug.WriteLine(message);
			}
			
			var dispatcher = Current.Dispatcher;
			if (dispatcher.CheckAccess())
			{
				ShowArgs(args);
			}
			else
			{
				dispatcher.BeginInvoke(
					new Action(delegate
					{
						ShowArgs(args);
					}));
			}
		}

		static void ShowArgs(IEnumerable<string> args)
		{
			var mainWindow = Current.MainWindow as MainWindow;
			if (mainWindow != null && args != null)
			{
				foreach (var arg in args)
				{
					mainWindow.ViewModel.Args.Add(arg);
				}
			}
		}

	}
}
