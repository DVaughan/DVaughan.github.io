﻿using System.Collections.ObjectModel;
using System.ComponentModel;

namespace SingleApp
{
	public class MainWindowViewModel : INotifyPropertyChanged
	{
		static ObservableCollection<string> args = new ObservableCollection<string>();

		public ObservableCollection<string> Args
		{
			get
			{
				return args;
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string propertyName)
		{
			var temp = PropertyChanged;
			if (temp != null)
			{
				temp(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}
