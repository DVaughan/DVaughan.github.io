﻿using System.Reflection;

using Outcoder.Reflection;

namespace CalciumTemplateApp.ApplicationModel
{
	static class BuildInfo
	{
		static AssemblyBuildTime buildTime;

		internal static AssemblyBuildTime AssemblyBuildTime
		{
			get
			{
				if (buildTime == null)
				{
					Assembly assembly = typeof(BuildInfo).GetAssembly();
					buildTime = assembly.GetBuildTime();
				}

				return buildTime;
			}
		}
	}

}
