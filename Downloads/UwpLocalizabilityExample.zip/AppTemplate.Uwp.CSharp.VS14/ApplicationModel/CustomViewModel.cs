﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;

using Outcoder;
using Outcoder.ApplicationModel;
using Outcoder.ComponentModel;
using Outcoder.LauncherModel.Launchers;
using Outcoder.Messaging;
using Outcoder.Services;
using Outcoder.Services.Implementation;
using Outcoder.UI.Xaml;

namespace CalciumTemplateApp
{
	/// <summary>
	/// This is the base class for viewmodels within the project.
	/// When using the Visual Studio Add New Item dialog to create
	/// a new Calcium View, the viewmodel will inherit from this class.
	/// It is, therefore, a key extensibility point for Calcium.
	/// </summary>
	public abstract partial class CustomViewModel
		: ViewModelBase, IMessageSubscriber<SettingChangeEventArgs>,
			IMessageSubscriber<ApplicationLifeCycleMessage>
	{
		protected CustomViewModel() : this((string)null)
		{
			/* Intentionally left blank. */
		}

		/// <summary>
		/// Use this constructor to supply a title for the viewmodel.
		/// The title can be later changed using the Title property.
		/// </summary>
		/// <param name="title">The title.</param>
		protected CustomViewModel(string title) : base(title)
		{
			/* Prevent an exception being raised at design time. 
			 * This allows you to use a design time data context for your view 
			 * by inserting the following attribute in a top level control: 
			 * d:DataContext="{d:DesignInstance local:YourViewModel, IsDesignTimeCreatable=True}" */
			if (EnvironmentValues.DesignTime)
			{
				return;
			}

			reviewCommand = new DelegateCommand(obj => Review());
			registerCommand = new DelegateCommand(obj => RegisterAsync(), true, obj => CanRegisterAsync());
			buyFullVersionCommand = new DelegateCommand(obj => BuyFullVersion());

			/* MessageBus is a weak referencing event notification system. */
			var messageBus = Dependency.Resolve<IMessenger>();
			messageBus.Subscribe(this);
		}

		protected CustomViewModel(Func<object> titleFunc) : this((string)null)
		{
			TitleFunc = titleFunc;
		}

		Task<bool> CanRegisterAsync()
		{
			var licensingService = Dependency.Resolve<IMarketplaceService>();
			return Task.FromResult(licensingService.Trial);
		}

		void Review()
		{
			var marketplaceService = Dependency.Resolve<IMarketplaceService>();
			marketplaceService.Review();
		}

		readonly DelegateCommand reviewCommand;

		/// <summary>
		/// Gets the review command, which causes the built-in marketplace app to launch.
		/// When debugging the marketplace task is replaced with a mock task. 
		/// See the <see cref="Bootstrapper"/> for more information.
		/// </summary>
		public ICommand ReviewCommand => reviewCommand;

		async Task RegisterAsync()
		{
			var marketplaceService = Dependency.Resolve<IMarketplaceService>();
			await marketplaceService.RegisterAsync();
		}

		readonly DelegateCommand registerCommand;

		/// <summary>
		/// Gets the register command, which causes the built-in marketplace app to launch.
		/// When debugging the marketplace task is replaced with a mock task. 
		/// See the <see cref="Bootstrapper"/> for more information.
		/// </summary>
		public ICommand RegisterCommand => registerCommand;

		string visualState;

		/// <summary>
		/// Gets or sets the current visual state of the app 
		/// that is automatically transitioned to using an attached property 
		/// in the view. <see cref="VisualStateUtility"/>
		/// The <c>VisualStateUtility</c> uses the VisualStateManager 
		/// to set the visual state value.
		/// </summary>
		/// <value>
		/// The view's visual state.
		/// </value>
		public string VisualState
		{
			get
			{
				return visualState;
			}
			protected set
			{
				Assign(ref visualState, value);
			}
		}

		/// <summary>
		/// Gets the global app settings.
		/// </summary>
		public AppSettings AppSettings => AppSettings.Instance;

		/// <summary>
		/// This method is called when a setting is changed.
		/// </summary>
		/// <param name="message">
		/// The <see cref="Outcoder.Services.SettingChangeEventArgs"/> 
		/// instance containing the event data.</param>
		public virtual Task ReceiveMessage(SettingChangeEventArgs message) => Task.FromResult(0);

		/// <summary>
		/// If the user has not already consented to the app running under the lock screen
		/// a confirmation dialog is displayed.
		/// </summary>
		protected async Task PromptForLockScreenConsentIfNecessary()
		{
			var lockScreenService = Dependency.Resolve<ILockScreenService, LockScreenService>();

			if (lockScreenService.UserPrompted)
			{
				return;
			}

			bool response = await DialogService.AskYesNoQuestionAsync(
				Strings.Question_AllowTheAppToRunUnderTheLockScreen_Message,
				Strings.Question_AllowTheAppToRunUnderTheLockScreen_Caption);

			lockScreenService.RunningUnderLockScreenEnabled = response;
			lockScreenService.UserPrompted = true;
		}

		protected bool TrialVersion => DeploymentConfiguration.Trial;

		protected bool FreeVersion => DeploymentConfiguration.Free;

		protected bool PaidVersion => DeploymentConfiguration.Paid;

		public bool ShowAds => DeploymentConfiguration.ShowAds;

		Task IMessageSubscriber<ApplicationLifeCycleMessage>.ReceiveMessage(
			ApplicationLifeCycleMessage message)
		{
			if (message.State == ApplicationLifeCycleState.Activated)
			{
				OnPropertyChanged(() => FreeVersion);
				OnPropertyChanged(() => PaidVersion);
				OnPropertyChanged(() => TrialVersion);
			}

			return Task.FromResult(0);
		}

		readonly DelegateCommand buyFullVersionCommand;

		public ICommand BuyFullVersionCommand => buyFullVersionCommand;

		void BuyFullVersion()
		{
			var task = Dependency.Resolve<IMarketplaceDetailLauncher>();
			/* You can use a different content identifier 
			 * if your app exists in both the free and paid categories. */
			//task.ContentIdentifier = DeploymentConfiguration.PaidAppProductId;
			task.ShowAsync();
		}

		readonly static BindableStrings strings = new BindableStrings();

		public BindableStrings Strings => strings;

		protected void HandleUICultureChange()
		{
			strings.TriggerUpdateBindings();
			// ReSharper disable once ExplicitCallerInfoArgument
			OnPropertyChanged(nameof(Title));
		}
	}
}
