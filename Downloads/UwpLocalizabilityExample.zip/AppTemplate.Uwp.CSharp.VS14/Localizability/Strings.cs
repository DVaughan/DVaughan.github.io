﻿using Windows.ApplicationModel.Resources;
using Windows.ApplicationModel.Resources.Core;
using Windows.Foundation.Collections;

using System;
using System.ComponentModel;

using Outcoder;
using Outcoder.Services;
 
namespace CalciumTemplateApp 
{
public partial class Strings 
{
	static readonly ResourceLoader resourceLoader; 
 
	static Strings() 
	{
		try
		{
			resourceLoader = ResourceLoader.GetForViewIndependentUse("Strings");
		}
		catch (TypeInitializationException ex)
		{
			throw new Exception("Unable to locate the .resw file with the name: Strings.resw", ex);
		}
	}

	public static string AppTitle => RetrieveString("AppTitle");
	public static string Commands_Register => RetrieveString("Commands_Register");
	public static string Commands_Review => RetrieveString("Commands_Review");
	public static string Commands_Share => RetrieveString("Commands_Share");
	public static string Commands_UpgradeToFullVersion => RetrieveString("Commands_UpgradeToFullVersion");
	public static string Commands_ViewDashboard => RetrieveString("Commands_ViewDashboard");
	public static string DialogService_DefaultErrorCaption => RetrieveString("DialogService_DefaultErrorCaption");
	public static string DialogService_DefaultMessageCaption => RetrieveString("DialogService_DefaultMessageCaption");
	public static string DialogService_DefaultQuestionCaption => RetrieveString("DialogService_DefaultQuestionCaption");
	public static string DialogService_DefaultWarningCaption => RetrieveString("DialogService_DefaultWarningCaption");
	public static string Options_Categories_Advanced => RetrieveString("Options_Categories_Advanced");
	public static string Options_Categories_General => RetrieveString("Options_Categories_General");
	public static string Options_ConfirmAppClose_Title => RetrieveString("Options_ConfirmAppClose_Title");
	public static string Options_RunUnderLockScreen_Title => RetrieveString("Options_RunUnderLockScreen_Title");
	public static string Options_SystemTrayVisible_Description => RetrieveString("Options_SystemTrayVisible_Description");
	public static string Options_SystemTrayVisible_Title => RetrieveString("Options_SystemTrayVisible_Title");
	public static string Question_AllowTheAppToRunUnderTheLockScreen_Caption => RetrieveString("Question_AllowTheAppToRunUnderTheLockScreen_Caption");
	public static string Question_AllowTheAppToRunUnderTheLockScreen_Message => RetrieveString("Question_AllowTheAppToRunUnderTheLockScreen_Message");
	public static string ResourceFlowDirection => RetrieveString("ResourceFlowDirection");
	public static string ResourceLanguage => RetrieveString("ResourceLanguage");
	public static string Views_About_AppDescription => RetrieveString("Views_About_AppDescription");
	public static string Views_About_CreatedBy => RetrieveString("Views_About_CreatedBy");
	public static string Views_About_Title => RetrieveString("Views_About_Title");
	public static string Views_About_Version => RetrieveString("Views_About_Version");
	public static string Views_About_Version_Format1 => RetrieveString("Views_About_Version_Format1");
	public static string Views_Dashboard_Title => RetrieveString("Views_Dashboard_Title");
	public static string Views_Main_AppBar_Hub => RetrieveString("Views_Main_AppBar_Hub");
	public static string Views_Main_AppBar_Launchpad => RetrieveString("Views_Main_AppBar_Launchpad");
	public static string Views_Main_Title => RetrieveString("Views_Main_Title");
	public static string Views_Options_Title => RetrieveString("Views_Options_Title");
	static IStringParserService stringParserService;
	static readonly object stringParserServiceLock = new object();

	static string RetrieveString(string resourceKey)
	{
		string resourceString = resourceLoader.GetString(resourceKey);

		if (resourceString == null || !resourceString.Contains("${"))
		{
			return resourceString;
		}

		if (stringParserService == null)
		{
			lock (stringParserServiceLock)
			{
				if (stringParserService == null)
				{
					stringParserService = Dependency.Resolve<IStringParserService, StringParserService>();
				}
			}
		}

		var result = stringParserService.Parse(resourceString);
		return result;
	}

}

public class BindableStrings : INotifyPropertyChanged
{
	public BindableStrings()
	{
		var resourceContext = ResourceContext.GetForViewIndependentUse();
		resourceContext.QualifierValues.MapChanged += HandleMapChanged;
	}

	void HandleMapChanged(IObservableMap<string, string> sender, IMapChangedEventArgs<string> @event)
	{
		var dispatcher = Windows.UI.Xaml.Window.Current.Dispatcher;
		if (dispatcher.HasThreadAccess)
		{
			TriggerUpdateBindings();
		}
		else
		{
			dispatcher.RunAsync(CoreDispatcherPriority.Normal, TriggerUpdateBindings);
		}
	}

	public event PropertyChangedEventHandler PropertyChanged;

	public void TriggerUpdateBindings()
	{
		var handlers = PropertyChanged;
		if (handlers != null)
		{
			handlers(this, new PropertyChangedEventArgs(string.Empty));
		}
	}
	public string AppTitle => Strings.AppTitle;
	public string Commands_Register => Strings.Commands_Register;
	public string Commands_Review => Strings.Commands_Review;
	public string Commands_Share => Strings.Commands_Share;
	public string Commands_UpgradeToFullVersion => Strings.Commands_UpgradeToFullVersion;
	public string Commands_ViewDashboard => Strings.Commands_ViewDashboard;
	public string DialogService_DefaultErrorCaption => Strings.DialogService_DefaultErrorCaption;
	public string DialogService_DefaultMessageCaption => Strings.DialogService_DefaultMessageCaption;
	public string DialogService_DefaultQuestionCaption => Strings.DialogService_DefaultQuestionCaption;
	public string DialogService_DefaultWarningCaption => Strings.DialogService_DefaultWarningCaption;
	public string Options_Categories_Advanced => Strings.Options_Categories_Advanced;
	public string Options_Categories_General => Strings.Options_Categories_General;
	public string Options_ConfirmAppClose_Title => Strings.Options_ConfirmAppClose_Title;
	public string Options_RunUnderLockScreen_Title => Strings.Options_RunUnderLockScreen_Title;
	public string Options_SystemTrayVisible_Description => Strings.Options_SystemTrayVisible_Description;
	public string Options_SystemTrayVisible_Title => Strings.Options_SystemTrayVisible_Title;
	public string Question_AllowTheAppToRunUnderTheLockScreen_Caption => Strings.Question_AllowTheAppToRunUnderTheLockScreen_Caption;
	public string Question_AllowTheAppToRunUnderTheLockScreen_Message => Strings.Question_AllowTheAppToRunUnderTheLockScreen_Message;
	public string ResourceFlowDirection => Strings.ResourceFlowDirection;
	public string ResourceLanguage => Strings.ResourceLanguage;
	public string Views_About_AppDescription => Strings.Views_About_AppDescription;
	public string Views_About_CreatedBy => Strings.Views_About_CreatedBy;
	public string Views_About_Title => Strings.Views_About_Title;
	public string Views_About_Version => Strings.Views_About_Version;
	public string Views_About_Version_Format1 => Strings.Views_About_Version_Format1;
	public string Views_Dashboard_Title => Strings.Views_Dashboard_Title;
	public string Views_Main_AppBar_Hub => Strings.Views_Main_AppBar_Hub;
	public string Views_Main_AppBar_Launchpad => Strings.Views_Main_AppBar_Launchpad;
	public string Views_Main_Title => Strings.Views_Main_Title;
	public string Views_Options_Title => Strings.Views_Options_Title;
}
}
