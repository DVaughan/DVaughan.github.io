﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace CalciumTemplateApp.UI
{
	public sealed partial class PivotHeaderButton : UserControl
	{
		public static readonly DependencyProperty GlyphProperty 
			= DependencyProperty.Register(
				"Glyph",
				typeof(string),
				typeof(PivotHeaderButton),
				null);

		public string Glyph
		{
			get
			{
				return (string)GetValue(GlyphProperty);
			}
			set
			{
				SetValue(GlyphProperty, value);
			}
		}

		public static readonly DependencyProperty LabelProperty 
			= DependencyProperty.Register(
				"Label",
				typeof(string),
				typeof(PivotHeaderButton),
				null);

		public string Label
		{
			get
			{
				return (string)GetValue(LabelProperty);
			}
			set
			{
				SetValue(LabelProperty, value);
			}
		}


		public PivotHeaderButton()
		{
			InitializeComponent();
			DataContext = this;
		}
	}
}
