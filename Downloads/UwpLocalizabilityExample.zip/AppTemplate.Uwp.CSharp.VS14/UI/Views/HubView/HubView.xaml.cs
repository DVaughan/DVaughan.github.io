﻿using Windows.UI.Xaml.Controls;

namespace CalciumTemplateApp.UI
{
	public sealed partial class HubView : Page
	{
		public HubView()
		{
			DataContext = new HubViewModel();

			this.InitializeComponent();
		}

		public HubViewModel Model => (HubViewModel)DataContext;
	}
}
