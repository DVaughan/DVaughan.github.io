﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

using Outcoder.ComponentModel;

namespace CalciumTemplateApp.UI
{
	public class HubViewModel : CustomViewModel, ICompositeViewModel
	{
		public HubViewModel()
		{
			LoadChildViewModels();
		}

		void LoadChildViewModels()
		{
			childViewModels.Clear();

			childViewModels.Add(new OptionsViewModel());
			childViewModels.Add(new AboutViewModel());
        }

		readonly ObservableCollection<ViewModelBase> childViewModels 
			= new ObservableCollection<ViewModelBase>(); 

		public IEnumerable<ViewModelBase> ChildViewModels => childViewModels;

		public void ActivateViewModel(ViewModelBase viewModel)
		{
			ActiveChildViewModel = viewModel;
		}

		ViewModelBase activeChildViewModel;

		public ViewModelBase ActiveChildViewModel
		{
			get
			{
				return activeChildViewModel;
			}
			set
			{
				Assign(ref activeChildViewModel, value);
			}
		}
	}
}
