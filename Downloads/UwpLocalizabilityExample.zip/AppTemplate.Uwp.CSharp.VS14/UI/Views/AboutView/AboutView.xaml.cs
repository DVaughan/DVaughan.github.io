﻿using Windows.UI.Xaml.Controls;

namespace CalciumTemplateApp.UI
{
	public sealed partial class AboutView : Page
	{
		public AboutView()
		{
			this.InitializeComponent();
		}

		public AboutViewModel Model => (AboutViewModel)DataContext;
	}
}
