﻿using CalciumTemplateApp.ApplicationModel;

namespace CalciumTemplateApp.UI
{
	public class AboutViewModel : CustomViewModel
	{
		public AboutViewModel()
		{
			TitleFunc = () => Strings.Views_About_Title;

			GlyphFunc = () => '\uE909'; /* World Icon */
		}

		public string Version => BuildInfo.AssemblyBuildTime.DisplayVersion;
	}
}
