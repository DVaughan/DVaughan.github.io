﻿using System.Threading.Tasks;

using Outcoder;
using Outcoder.ComponentModel;
using Outcoder.Messaging;
using Outcoder.Services;

namespace CalciumTemplateApp.UI.Settings
{
	public class MainViewSettings : ObservableObject, IMessageSubscriber<SettingChangeEventArgs>
	{
		readonly ISettingsService settingsService;

		public MainViewSettings(ISettingsService settingsService)
		{
			this.settingsService = ArgumentValidator.AssertNotNull(settingsService, "settingsService");			
		}

		Task IMessageSubscriber<SettingChangeEventArgs>.ReceiveMessage(SettingChangeEventArgs message)
		{
			OnPropertyChanged(message.SettingName);
			return Task.FromResult(0);
		}

		const string SystemTrayVisibleKey = "SystemTrayVisible";
		static bool systemTrayVisibleDefaultValue = true;

		public bool SystemTrayVisible
		{
			get
			{
				return settingsService.GetSetting(SystemTrayVisibleKey, systemTrayVisibleDefaultValue);
			}
			set
			{
				settingsService.SetSetting(SystemTrayVisibleKey, value);
			}
		}
	}
}
