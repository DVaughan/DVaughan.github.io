﻿using System.Windows.Input;

using Outcoder;
using Outcoder.UI.Xaml;

namespace CalciumTemplateApp.UI
{
	public class MainViewModel : CustomViewModel
	{
		public MainViewModel()
		{
			navigateToHubCommand = new DelegateCommand(NavigateToHub);
			toggleLaunchPadCommand = new DelegateCommand(ToggleLaunchPad);
		}

		#region Navigate to Hub Command

		readonly DelegateCommand navigateToHubCommand;

		public ICommand NavigateToHubCommand => navigateToHubCommand;

		void NavigateToHub(object arg)
		{
			Navigate(typeof(HubView));
		}
		
		#endregion

		#region Launchpad Visibility

		readonly DelegateCommand toggleLaunchPadCommand;

		public ICommand ToggleLaunchPadCommand => toggleLaunchPadCommand;

		void ToggleLaunchPad(object arg)
		{
			HideContextMenus();

			SetLaunchPadVisibility(!launchPadVisible);
		}

		void SetLaunchPadVisibility(bool visible)
		{
			if (!visible)
			{
				//var messageBus = Dependency.Resolve<IMessenger>();
				//messageBus.Publish(new HaltUIActivitiesMessage<LaunchPadViewModel>(true));
			}

			if (launchPadVisible == visible)
			{
				return;
			}

			LaunchPadVisible = visible;

			BeginInvoke(delegate
			{
				VisualState = visible ? "LaunchPadVisible" : "LaunchPadHidden";
			});
		}

		bool launchPadVisible;

		public bool LaunchPadVisible
		{
			get
			{
				return launchPadVisible;
			}
			private set
			{
				Assign(ref launchPadVisible, value);
			}
		}

		internal void HandleLaunchpadClosing()
		{
			SetLaunchPadVisibility(false);
		}

		#endregion

		void HideContextMenus()
		{
			/* Place code to hide any flyout menus here. */
		}


	}
}
