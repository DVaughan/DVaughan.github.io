﻿using System.Linq;

using Outcoder;
using Outcoder.Services;
using Outcoder.UserOptionsModel;

namespace CalciumTemplateApp.UI
{
	public class OptionsViewModel : CustomViewModel
	{
		public OptionsViewModel()
		{
			TitleFunc = () => Strings.Views_Options_Title;
			GlyphFunc = () => '\uE713';

			LoadOptions();
			NavigatingFrom += HandleNavigatingFrom;
		}

		void HandleNavigatingFrom(object sender, System.ComponentModel.CancelEventArgs e)
		{
			SaveOptions();
		}

		void LoadOptions()
		{
			var userOptionsService = Dependency.Resolve<IUserOptionsService>();
			UserOptionGroupings = userOptionsService.UserOptionGroupings;
		}

		void SaveOptions()
		{
			if (UserOptionGroupings == null)
			{
				return;
			}

			foreach (IGrouping<IOptionCategory, IUserOptionReaderWriter> grouping
														in UserOptionGroupings)
			{
				foreach (IUserOptionReaderWriter writer in grouping)
				{
					writer.Save();
				}
			}
		}

		IUserOptionGroupings userOptionGroupings;

		/// <summary>
		/// Gets the user option groupings. 
		/// The are groups of options split by <see cref="IOptionCategory"/>.
		/// </summary>
		public IUserOptionGroupings UserOptionGroupings
		{
			get
			{
				return userOptionGroupings;
			}
			private set
			{
				Assign(ref userOptionGroupings, value);
			}
		}
	}
}