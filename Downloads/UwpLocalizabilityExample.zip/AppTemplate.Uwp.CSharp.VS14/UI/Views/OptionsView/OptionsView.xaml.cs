﻿using Windows.UI.Xaml.Controls;

namespace CalciumTemplateApp.UI
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class OptionsView : Page
	{
		public OptionsView()
		{
			this.InitializeComponent();
		}

		public OptionsViewModel Model => (OptionsViewModel)DataContext;
	}
}
