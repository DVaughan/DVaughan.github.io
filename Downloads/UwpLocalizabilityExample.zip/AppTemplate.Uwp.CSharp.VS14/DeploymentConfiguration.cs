﻿#define PAID // Comment or uncomment depending on whether your publishing a paid or free app.

using Outcoder;
using Outcoder.Services;

namespace CalciumTemplateApp
{
	class DeploymentConfiguration
	{
		/* Once you know the paid app ID on the Windows Phone Marketplace, update this field. 
		 * This allows the user to purchase the app from the free version. */
		const string paidAppProductId = "11111111-1111-1111-1111-111111111111";

		/* Set this constants if you are using Microsoft pubCenter advertising. */
		const string pubCenterAdId = "11111111-1111-1111-1111-111111111111";
		const string pubCenterAdUnitId = "11111111-1111-1111-1111-111111111111";

		public static string AdAppId
		{
			get
			{
#if DEBUG
				return "test_client";
#else
				return pubCenterAdId;
#endif
			}
		}

		public static string AdUnitId
		{
			get
			{
#if DEBUG
				return "Image300_50";
#else
				return pubCenterAdUnitId;
#endif
			}
		}

		/* This should be false when publishing 
		 * a paid version; true otherwise. */
		public static bool ShowAds
		{
			get
			{
				return !PaidConfiguration;
			}
		}

		public static bool Paid
		{
			get
			{
				return PaidConfiguration;
			}
		}

		public static bool Free
		{
			get
			{
				return !PaidConfiguration;
			}
		}

		static bool? trial;

		public static bool Trial
		{
			get
			{
				if (!trial.HasValue)
				{
					var marketplaceService = Dependency.Resolve<IMarketplaceService>();
					trial = marketplaceService.Trial;
				}

				return trial.Value;
			}
		}

		public const bool PaidConfiguration =
#if PAID
			true;
#else
			false;
#endif

		public static string PaidAppProductId
		{
			get
			{
				return paidAppProductId;
			}
		}

		public static bool DebugBuild
		{
			get
			{
#if DEBUG
				return true;
#else
				return false;
#endif
			}
		}
	}
}